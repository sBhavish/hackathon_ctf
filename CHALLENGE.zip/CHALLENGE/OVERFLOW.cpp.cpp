#include <iostream>
#include<stdlib.h>//for rand() method

int main(void)
{
  int arr[10];
  
  int num=100,i;

  for (i = 0; i < num; i++)
  {
    
    arr[i]= rand();//taking inputs randomly implicitly
    std::cout<<arr[i]<<"\n";
  }
  return 0;
}
